#! /bin/sh
spark-submit spark-cassandra.py
