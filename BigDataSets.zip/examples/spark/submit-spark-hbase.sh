#! /bin/sh
spark-submit --jars "/usr/local/spark/jars/spark-xml.jar" /examples/spark/spark-hbase.py

