#! /bin/sh
spark-submit --packages mysql:mysql-connector-java:5.1.39 spark-mysql.py
